<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Permission;
use App\Http\Requests;
use Datatables;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;

class PermissionsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci = [
            ['name','permissions.name','Naziv Dozvole',0,true,true,true],
            ['display_name','permissions.display_name','Duži naziv',1,true,true,true],
            ['description','permissions.description','Naziv Operatera',2,true,true,true],
            ['created_at','permissions.created_at','Kreirana',3,true,false,false],
            ['updated_at','permissions.updated_at','Ažurirana',4,true,false,false],
            ['action','Akcije','Akcije',5,true,false,false]
        ];
        view()->share('description', $this->getDescription('Dozvole'));

        View::share('naslovTabele', 'Dozvole');
        View::share('naslovModala', 'Dozvola');
        View::share('textDodajGumba', 'Dodaj Dozvolu');
        View::share('tabelaStupci', $tabelaStupci);
        View::share('formName', 'dozvole');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('datatables.admin.dozvole.index');
    }

    public function BasicData()
    {
        $dozvole = Permission::all();

        return Datatables::of($dozvole)
            ->editColumn('Naziv', function ($dozvole) {
                return '<a href="dozvole/'.$dozvole->id.'">'.$dozvole->Naziv.'</a>';
            })
            ->addColumn('action', function ($dozvole) {
                return '<a class="edit" data-toggle="modal" data-target="#Modal" data-action="dozvole/'.$dozvole->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="dozvole/'.$dozvole->id.'" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        ';
            })
            ->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            Permission::create($request->all());
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Dozvola je dodana');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Permission $permission
     * @return \Illuminate\Http\Response
     */
    public function show(Permission $permission)
    {
        return response()->json($permission);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Permission $permission
     * @return \Illuminate\Http\Response
     */
    public function update(Permission $permission, Request $request)
    {
        try {
            $permission->fill($request->all())->save();
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Dozvola je uređena');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Permission $permission
     * @return \Illuminate\Http\Response
     * pošto je veza many to many malo to provjeriti
     */
    public function destroy(Permission $permission)
    {
        try {
            $permission->destroy($permission->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Dozvola je uspješno obrisana');
        return back();
    }
}
