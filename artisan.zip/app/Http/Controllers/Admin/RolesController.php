<?php

namespace App\Http\Controllers\Admin;

use App\Permission;
use Illuminate\Http\Request;
use App\Role;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Datatables;
use Illuminate\Support\Facades\Session;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Cache;

class RolesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci = [
            ['name','name','Naziv Uloge',0,true,true,true],
            ['display_name','display_name','Za prikaz',1,true,false,false],
            ['description','description','Opis',2,true,false,false],
            ['created_at','created_at','Kreirana',3,true,false,false],
            ['updated_at','updated_at','Ažurirana',4,true,false,false],
            ['action','Akcije','Akcije',5,true,false,false]
        ];
        if (!Cache::has("Dozvole")) {
            $dozvole = Permission::all();
            Cache::forever("Dozvole", $dozvole);
        }
        view()->share('description', $this->getDescription('Uloge'));


        View::share(['dozvole' =>  Cache::get("Dozvole")] );
        View::share('naslovTabele', 'Uloge');
        View::share('naslovModala', 'Uloga');
        View::share('textDodajGumba', 'Dodaj Ulogu');
        View::share('tabelaStupci', $tabelaStupci);
        View::share('formName', 'uloge');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('datatables.admin.uloge.index');
    }

    public function BasicData()
    {
        $role = Role::all();

        return Datatables::of($role)
            ->addColumn('ime', function ($role) {
                return '<a href="admin/dozvole/' . $role->id . '">' . $role->Naziv. '</a>';
            })
            ->addColumn('action', function ($role) {
                return '<a class="edit" data-toggle="modal" data-target="#Modal" data-action="uloge/'.$role->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="uloge/'.$role->id.'" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        <a href="dozvole" ><i class="glyphicon glyphicon-edit"></i></a>
                        ';
            })
            ->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $role = Role::create($request->all());
            $this->syncDozvole($role, $request->input('dozvole'));
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Uloga je dodana');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Role $role
     * @return \Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        //$role = $role->load('dozvole');
        return response()->json($role->load('dozvole'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Role $role
     * @return \Illuminate\Http\Response
     */
    public function update(Role $role, Request $request)
    {
        try {
            $role->update($request->all());
            $this->syncDozvole($role, $request->input('dozvole'));
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Uloga je uređena');
        return back();
    }

    private function syncDozvole(Role $role, array $dozvole){
        $role->dozvole()->sync($dozvole);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Role $role
     * @return \Illuminate\Http\Response
     * pošto je veza many to many malo to provjeriti
     */
    public function destroy(Role $role)
    {
        try {
            $role->destroy($role->id);
            $role->dozvole()->sync([]);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Uloga je uspješno obrisana');
        return back();
    }
}
