<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Role;
use App\Services\PorukeOperaterima;
use Datatables;
use App\User;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use Laracasts\Flash\Flash;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Cache;

class UsersController extends Controller
{
  public function __construct()
    {
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci = [
            ['name','Operateri.name','Naziv Operatera',0,true,true,true],
            ['created_at','Operateri.created_at','Kreiran',1,true,false,false],
            ['updated_at','Operateri.updated_at','Ažuriran',2,true,false,false],
            ['action','Akcije','Akcije',3,true,false,false]
        ];
        if (!Cache::has("Uloge")) {
            $role = Role::all();
            Cache::forever("Uloge", $role);
        }

        view()->share('description', $this->getDescription('Operateri'));
        View::share(['uloge' =>  Cache::get("Uloge")] );
        View::share('naslovTabele', 'Operateri');
        View::share('naslovModala', 'Operater');
        View::share('textDodajGumba', 'Dodaj Operatera');
        View::share('tabelaStupci', $tabelaStupci);
        View::share('formName', 'operateri');
    }

   public function index(){
       return view('datatables.admin.operateri.index');
   }

   public function BasicData()
   {
       $operateri = User::with('roles','roles.dozvole');

       return Datatables::of($operateri)
            ->addColumn('action', function ($operateri) {
                return '<a class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="operateri/'.$operateri->id.'"><span class="glyphicon glyphicon-edit"></a>
                        <a href="operateri/'.$operateri->id.'" title="Obriši" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>';
            })
           ->make(true);
   }


   public function show(User $user){
           return response()->json($user->load(['roles','roles.dozvole']));
   }

   public function store(Request $request){
       try {
           $user = User::create($request->all());
           $this->syncUloge($user, $request->input('roles'));
       }catch (\Illuminate\Database\QueryException $e) {
           dd($e->errorInfo[1]);
           Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
           return back();
       }
       Flash::success('Operater je dodan');
       return back();
   }

   public function update(User $user, Request $request){
       try {
           $user->update(['name' => Input::get('name'),'email' => Input::get('email'),'password' => Hash::make(Input::get('password'))]);
           $this->syncUloge($user, $request->input('roles'));
       }catch (\Illuminate\Database\QueryException $e) {
           dd($e->errorInfo[1]);
           Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
           return back();
       }
       Flash::success('Operater je uređen');
       return back();
   }

    private function syncUloge(User $user, array $role){
        $user->roles()->sync($role);
    }

   public function destroy(User $user){
        try {
            $user->delete($user->id);
            $user->role()->sync([]);
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
       Flash::success('Operater je uspješno obrisan');
       return back();
   }

}

