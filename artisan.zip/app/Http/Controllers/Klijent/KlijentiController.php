<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\ZiroRacun;
use Illuminate\Http\Request;
use Datatables;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\View;

class KlijentiController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $tabelaStupci = [
            ['Naziv','Predlosci.Naziv','Naziv Klijenta',0,true,true,true],
            ['created_at','created_at','Napravljen',1,true,true,true],
            ['updated_at','updated_at','Promjenjen',2,true,true,true],
            ['action','Akcije','Akcije',3,true,false,false]
        ];

        if(Auth::user()){
            $this->klijenti = Auth::user()->klijenti()->get();
        }
        view()->share('description', $this->getDescription('Klijenti'));
        view()->share('naslovModala', 'Klijent');
        view()->share('textDodajGumba', 'Dodaj Klijenta');
        view()->share('formName', 'klijent');
        View::share('naslovTabele', 'Klijenti');
        View::share('tabelaStupci', $tabelaStupci);
       
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->klijenti->count() == 1) {
            Session::put('klijentId', $this->klijenti->first()->id);
            Flash::success('Klijent je odabran automatski');
            return redirect('klijenti/'.$this->klijenti->first()->id.'/partneri');
        } else {
            $klijent = $this->klijenti->first();
            return view('datatables.klijenti.index', compact('klijenti','klijent'));
        }
    }

    public function BasicData()
    {
        $klijenti = $this->klijenti;
        return Datatables::of($klijenti)
                ->editColumn('created_at', function ($klijenti) {
                    return $klijenti->created_at->format('d.m.Y H:i:s');
                })
                ->editColumn('updated_at', function ($klijenti) {
                    return $klijenti->updated_at->format('d.m.Y H:i:s');
                })
                ->editColumn('Naziv', function ($klijenti) {
                    return '<a href="klijenti/'.$klijenti->id.'/partneri">'.$klijenti->Naziv.'</a>';
                })
                ->addColumn('action', function ($klijenti) {
                    return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="klijenti/'.$klijenti->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                            <a href="klijenti/'.$klijenti->id.'" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                            <a href="klijenti/odaberi/'.$klijenti->id.'"><i class="glyphicon glyphicon-hand-down"></i></a>';
                })
                ->make(true);
    }

    /**
     * Odabir klijenta s kojim će se raditi
     *
     * @param  Klijent $klijenti
     */

    public function OdaberiKlijenta(Klijent $klijenti){
            Session::put('klijentId', $klijenti->id);            
            Flash::success('Klijent je odabran');
        return redirect('klijenti/'.$klijenti->id.'/partneri');
    }

    public function ProvjeraIbana(Request $request){

        $result = ZiroRacun::where('IBAN','like',$request->get('iban'))->select('id')->get();
        return response()->json($result);
    }
    public function DohvatiPartnera(Klijent $klijent, ZiroRacun $ziroRacun){

        return response()->json($ziroRacun->where('id',$ziroRacun->id)->with('partneri')->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $klijent = Klijent::create($request->all());
            Auth::user()->klijenti()->attach($klijent->id);
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Klijent je dodan');
        return back();
    }


    /**
     * Display the specified resource.
     *
     * @param  Klijent $klijent
     * @return \Illuminate\Http\Response
     */
    public function show(Klijent $klijent)
    {
        return response()->json($klijent);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Klijent $klijent)
    {
        try {
            $klijent->fill($request->all())->save();
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Klijent je uređen');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Klijent $klijent
     * @return \Illuminate\Http\Response
     * pošto je veza many to many malo to provjeriti
     */
    public function destroy(Klijent $klijent)
    {
        try {
            Auth::user()->klijenti()->detach($klijent->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Klijent je uspješno obrisan');
        return back();
    }
}
