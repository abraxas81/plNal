<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\Partner;
use Illuminate\Http\Request;
use Datatables;
use Laracasts\Flash\Flash;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class KlijentiPartneriController extends Controller
{
    public function __construct()
    {
        $tabelaStupci = [
            ['Naziv','Naziv','Naziv Klijenta',0,true,true,true],
            ['Adresa','Adresa','Adresa',1,true,true,true],
            ['Email','Email','Email',2,true,true,true],
            ['Telefon','Telefon','Telefon',3,true,true,true],
            ['Mobitel','Mobitel','Mobitel',4,true,true,true],
            ['OIB','OIB','OIB',5,true,true,true],
            ['action','action','Akcije',6,true,false,false]
        ];

        $this->middleware('auth');
        view()->share('description', $this->getDescription('Partneri'));
        view()->share('naslovModala', 'Partner');
        view()->share('formPartneriName', 'partneri');
        view()->share('formName', 'partneri');
        view()->share('description', $this->getDescription('Klijenti'));
        view()->share('textDodajGumba', 'Dodaj Partnera');
        view()->share('naslovTabele', 'Klijenti');
        view()->share('tabelaStupci', $tabelaStupci);
    }

    /**
     * Display a listing of the resource.
     * @param Klijent $klijent
     * @return \Illuminate\Http\Response
     */
    public function index(Klijent $klijent)
    {
        return view('datatables.klijenti.partneri.index', compact('klijent'));
    }

    public function BasicData(Klijent $klijent, Request $request)
    {
        $partneri = $klijent->partneri()->get();

        return Datatables::of($partneri)
            //->editColumn('title','{!! str_limit($title, 60) !!}')
            ->editColumn('Naziv', function ($partneri) {
                return '<a href="partneri/' . $partneri->id . '/ziro">' . $partneri->Naziv . '</a>';
            })
            ->addColumn('action', function ($partneri) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="partneri/' . $partneri->id . '"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="partneri/' . $partneri->id . '" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                       ';})
            ->make(true);
    }

    //filters
/*->filter(function ($query) use ($request) {
                if ($request->get('tipKlijenta') == "platitelj") {
                    $query->where('Platitelj', 1);
                }
if ($request->get('tipKlijenta') == "primatelj") {
    $query->where('Primatelj', 1);
}
if ($_GET['search']['value'] != "") {
    $query->where('Naziv','like', "%{$_GET['search']['value']}%");
}
})*/

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @return \Illuminate\Http\Response
     */
    public function store(Klijent $klijent, Request $request)
    {
        try {
            $partner = Partner::create($request->all());
            $partner->klijenti()->attach($request->input('Klijenti_id'));
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Partner je dodan');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Klijent $klijent
     * @param  Partner $partner
     * @return \Illuminate\Http\Response
     */
    public function show(Klijent $klijent, Partner $partner)
    {
        $responseType = 0;
        if($responseType){
            $tabela = "<table>
                        <tr><td>Naziv :</td><td>$partner->Naziv</td></tr>
                        <tr><td>Adresa :</td><td>$partner->Adresa</td></tr>
                        <tr><td>Email :</td><td>$partner->Email</td></tr>
                        <tr><td>Telefon :</td><td>$partner->Telefon</td></tr>
                        <tr><td>Mobitel :</td><td>$partner->Mobitel</td></tr>
                        <tr><td>OIB :</td><td>$partner->OIB</td></tr>
                   </table>";
            return $tabela;
        } else {
            return response()->json($partner->load('ziroRacuni'));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @param  Partner $partner
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Klijent $klijent, Partner $partner)
    {
        try {
            $partner->update($request->all());
            $partner->klijenti()->attach($request->input('Klijenti_id'));
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Partner je uređen');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Klijent $klijent
     * @param  Partner $partner
     * @return \Illuminate\Http\Response
     */
    public function destroy(Klijent $klijent, Partner $partner)
    {
        try {
            $partner->delete();
            $partner->klijenti()->detach();
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Partner je uspješno obrisan');
        return back();
    }
}
