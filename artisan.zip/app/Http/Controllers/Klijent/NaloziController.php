<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\ModelPlacanja;
use App\Nalog;
use App\Valuta;
use App\SifraNamjene;
use Illuminate\Http\Request;
use Datatables;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Cache;

class NaloziController extends Controller
{
   public function __construct(){
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
       $tabelaStupci = [
           ['platitelj.IBAN','platitelj.IBAN','Iban Platitelja',0,true,false,false],
           ['ModelOdobrenjaId','Nalozi.ModelOdobrenjaId','Model Odobrenja',1,true,false,false],
           ['BrojOdobrenja','Nalozi.BrojOdobrenja','Broj Odobrenja',2,true,true,true],
           ['primatelj.IBAN','primatelj.IBAN','Iban primatelja',3,true,false,false],
           ['ModelZaduzenjaId','Nalozi.ModelZaduzenjaId','Model Zaduženja',4,true,false,true],
           ['BrojZaduzenja','Nalozi.BrojZaduzenja','Broj Zaduženja',5,true,true,true],
           ['Iznos','Nalozi.Iznos','Iznos',6,true,true,true],
           ['Opis','Nalozi.Opis','Opis',7,true,true,true],
           ['DatumIzvrsenja','Nalozi.DatumIzvrsenja','Datum Izvršenja',8,true,true,true],
           ['valute.Alfa','valute.Alfa','Valuta',9,true,false,false],
           ['action','Akcije','Akcije',10,true,false,false]
       ];
        view()->share('description', $this->getDescription('Predlosci'));
        if (!Cache::has("ModeliPlacanja")) {
            $ModeliPlacanja = ModelPlacanja::orderBy('Vrijednost')->get();
            Cache::forever("ModeliPlacanja", $ModeliPlacanja);
        }
        if (!Cache::has("Valute")) {
            $Valute = Valuta::all();
            Cache::forever("Valute", $Valute);
        }
        if (!Cache::has("SifreNamjene")) {
            $SifreNamjene = SifraNamjene::all();
            Cache::forever("SifreNamjene", $SifreNamjene);
        }
       if (!Cache::has(Session::get('klijentId')."Platitelji")) {
           Cache::forever(Session::get('klijentId') . "Platitelji", Klijent::find(Session::get('klijentId'))->partneri()->with('ziroRacuni')->Platitelj());
       }
       View::share(['Partneri' => Cache::get(Session::get('klijentId').'Platitelji')->get()]);
       View::share(['Primatelji' => Cache::get('Primatelji')]);
       View::share(['SifreNamjene' =>  Cache::get("SifreNamjene")] );
       View::share(['Valute' =>  Cache::get("Valute")] );
       View::share(['ModeliPlacanja' =>  Cache::get("ModeliPlacanja")] );

        View::share('naslovTabele', 'Nalozi');
        View::share('naslovModala', 'Nalog za plaćanje');
        View::share('textDodajGumba', 'Dodaj Nalog');
        View::share('tabelaStupci', $tabelaStupci);
        View::share('predlozak', false);
        View::share('formPartneriName', 'partneri');
        View::share('formName', 'nalozi');
        View::share('rutaDohvatPartnera', 'ziro/');
        View::share('RutaProvjeraIbana', 'ProvjeraIbana/');

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Klijent $klijent, Request $request)
    {
        $vrstaNalogaF = $request->get('vrstaNaloga');
        return view('datatables.klijenti.nalozi.index', compact('klijent','vrstaNalogaF'));
    }

    public function BasicData(Klijent $klijent)
    {
        $nalozi = $klijent->nalozi()->with('platitelj','primatelj','valute');

        $datatables =  app('datatables')->of($nalozi)
            ->editColumn('DatumIzvrsenja', function ($predlosci) {
                return date('d.m.Y',strtotime($predlosci->DatumIzvrsenja));
            })
            ->editColumn('platitelj.Naziv', function ($nalozi) {
                return '<a href="#" class="detalji" data-action="partneri/'.$nalozi->platitelj->id.'" data-title="Podaci o platitelju">'.$nalozi->platitelj->Naziv.'</a>';
            })
            ->editColumn('primatelj.Naziv', function ($nalozi) {
                return '<a href="#" class="detalji" data-action="partneri/'.$nalozi->primatelj->id.'" data-title="Podaci o primatelju">'.$nalozi->primatelj->Naziv.'</a>';
            })
            ->editColumn('Naziv', function ($nalozi) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="nalozi/'.$nalozi->id.'">'.$nalozi->Naziv.'</a>';
            })
            ->addColumn('action', function ($nalozi) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-platitelj="'.$nalozi->PlatiteljId.'" data-primatelj="'.$nalozi->ZiroPrimatelja.'" data-target="#Modal" data-action="nalozi/'.$nalozi->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="nalozi/'.$nalozi->id.'" title="Obriši" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        ';
            });

        // vrsta Naloga filter
        if ($vrstaNalogaFilter = $datatables->request->get('vrstaNalogaFilter')) {
            $datatables->where('VrstaNalogaId',  $vrstaNalogaFilter);
        }

        // slovo search
        if ($alphabetSearch = $datatables->request->get('alphabetSearch')) {
            $datatables->where('Nalozi.Naziv', 'like', "$alphabetSearch%");
        }

        return $datatables->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Klijent $klijent, Request $request)
    {
        try {
            $request->merge(['DatumIzvrsenja' => date('Y-m-d', strtotime($request->input('DatumIzvrsenja')))]);
            $nalog = Nalog::create($request->all());
            $klijent->nalozi()->attach($nalog);
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je kreiran');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function show(Klijent $klijent, Nalog $nalog)
    {
        return response()->json($nalog->load(['primatelj','primatelj.partneri']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function update(Klijent $klijent, Nalog $nalog, Request $request)
    {
        try {
            $request->merge(['DatumIzvrsenja' => date('Y-m-d', strtotime($request->input('DatumIzvrsenja')))]);
            $nalog->update($request->all());
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je uređen');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function destroy(Klijent $klijent, Nalog $nalog)
    {
        try {
            $nalog->destroy($nalog->id);
            $klijent->nalozi()->detach($nalog);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je uspješno obrisan');
        return back();
    }
}
