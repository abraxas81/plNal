<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\ModelPlacanja;
use App\Predlozak;
use App\Valuta;
use App\SifraNamjene;
use Illuminate\Http\Request;
use Datatables;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Cache;

class PredlosciController extends Controller
{
    public function __construct()
    {
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci2 = [
            ['Naziv','Naziv','Naziv Predloška',0,true,true,true],
            ['platitelj.IBAN','Predlosci.Naziv','Iban Platitelja',1,true,false,false],
            ['ModelOdobrenjaId','Predlosci.ModelOdobrenjaId','Model Odobrenja',2,true,false,false],
            ['BrojOdobrenja','Predlosci.BrojOdobrenja','Broj Odobrenja',3,true,true,true],
            ['primatelj.IBAN','Predlosci.IBAN','Iban Primatelja',4,true,false,false],
            ['ModelZaduzenjaId','Predlosci.ModelZaduzenjaId','Model Zaduženja',5,true,false,true],
            ['BrojZaduzenja','Predlosci.BrojZaduzenja','Broj Zaduženja',6,true,true,true],
            ['Iznos','Predlosci.Iznos','Iznos',7,true,true,true],
            ['Opis','Predlosci.Opis','Opis',8,true,true,true],
            ['valute.Alfa','valute.Alfa','Valuta',9,true,false,false],
            ['action','Akcije','Akcije',10,true,false,false]
        ];
        
        $this->middleware('auth');
        view()->share('description', $this->getDescription('Predlosci'));
        if (!Cache::has("ModeliPlacanja")) {
            $ModeliPlacanja = ModelPlacanja::all();
            Cache::forever("ModeliPlacanja", $ModeliPlacanja);
        }
        if (!Cache::has("Valute")) {
            $Valute = Valuta::all();
            Cache::forever("Valute", $Valute);
        }
        if (!Cache::has("SifreNamjene")) {
            $SifreNamjene = SifraNamjene::all();
            Cache::forever("SifreNamjene", $SifreNamjene);
        }
        if (!Cache::has(Session::get('klijentId')."Platitelji")) {
            Cache::forever(Session::get('klijentId') . "Platitelji", Klijent::find(Session::get('klijentId'))->partneri()->with('ziroRacuni')->Platitelj());
        }
        
        View::share(['Partneri' => Cache::get(Session::get('klijentId').'Platitelji')->get()]);
        View::share(['Primatelji' => Cache::get('Primatelji')]);
        View::share(['SifreNamjene' =>  Cache::get("SifreNamjene")] );
        View::share(['Valute' =>  Cache::get("Valute")] );
        View::share(['ModeliPlacanja' =>  Cache::get("ModeliPlacanja")] );

        View::share('naslovTabele', 'Predlošci');
        View::share('naslovModala', 'Predložak naloga za nacionalno plaćanje u kunama');
        View::share('textDodajGumba', 'Dodaj Predložak');
        View::share('tabelaStupci2', $tabelaStupci2);
        View::share('predlozak', true);
        View::share('selectedPredlosci', true);
        View::share('formName', 'predlozak');
        View::share('formPartneriName', 'partneri');
        View::share('rutaDohvatPartnera', 'ziro/');
        View::share('RutaProvjeraIbana', 'ProvjeraIbana/');

    }
    /**
     * Display a listing of the resource.
     *
     * @param  Klijent $klijent     *
     * @return \Illuminate\Http\Response

     */
    public function index(Klijent $klijent, Request $request)
    {
        $vrstaNalogaF = $request->get('vrstaNaloga');
        return view('datatables.klijenti.predlosci.index', compact('klijent','vrstaNalogaF'));
    }

    /**
     * Dohvacanje podataka preko ajaxa.
     *
     * @param  Klijent $klijent     *
     * @return \Illuminate\Http\Response

     */
    public function BasicData(Klijent $klijent)
    {
        $predlosci = $klijent->predlosci()->with('platitelj','primatelj','valute');
                /*->select(['id','Naziv','ModelOdobrenjaId','BrojOdobrenja','ModelZaduzenjaId','BrojZaduzenja','Iznos','Opis','DatumIzvrsenja','ValuteId','PlatiteljId','ZiroPrimatelja'])
                ->with([
                    'valute' => function($query){
                        $query->select(['id','Alfa']);
                    },'platitelj' => function($query){
                        $query->select(['id','Naziv']);
                    },'primatelj' => function($query){
                        $query->select(['id','IBAN']);
                    }]);*/

        $datatables =  app('datatables')->of($predlosci)
            ->editColumn('DatumIzvrsenja', function ($predlosci) {
                return date('d.m.Y',strtotime($predlosci->DatumIzvrsenja));
            })
            ->editColumn('platitelj.Naziv', function ($predlosci) {
                return '<a href="#" class="detalji" data-action="partneri/'.$predlosci->PlatiteljId.'" data-title="Podaci o platitelju">'.$predlosci->platitelj->IBAN.'</a>';
                })
            ->editColumn('primatelj.Naziv', function ($predlosci) {
                return '<a href="#" class="detalji" data-action="partneri/'.$predlosci->ZiroPrimatelja.'" data-title="Podaci o primatelju">'.$predlosci->primatelj->IBAN.'</a>';
            })
            ->editColumn('Naziv', function ($predlosci) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="predlosci/'.$predlosci->id.'">'.$predlosci->Naziv.'</a>';
            })
            ->addColumn('action', function ($predlosci) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-platitelj="'.$predlosci->PlatiteljId.'" data-primatelj="'.$predlosci->ZiroPrimatelja.'" data-target="#Modal" data-action="predlosci/'.$predlosci->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="predlosci/'.$predlosci->id.'" title="Obriši" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        ';
            });

        // vrsta Naloga filter
        if ($vrstaNalogaFilter = $datatables->request->get('vrstaNalogaFilter')) {
            $datatables->where('VrstaNalogaId',  $vrstaNalogaFilter);
        }

        // slovo search
        if ($alphabetSearch = $datatables->request->get('alphabetSearch')) {
            $datatables->where('Predlosci.Naziv', 'like', "$alphabetSearch%");
        }

        return $datatables->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Klijent $klijent, Request $request)
    {
        try {
            Predlozak::create($request->all());
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Predložak je dodan');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Predlozak $predlozak
     * @return \Illuminate\Http\Response
     */
    public function show(Klijent $klijent, Predlozak $predlozak)
    {
        return response()->json($predlozak->load(['primatelj','primatelj.partneri']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @param  Predlozak $predlozak
     * @return \Illuminate\Http\Response
     */
    public function update(Klijent $klijent, Predlozak $predlozak, Request $request)
    {
        try {
            $predlozak->update($request->all());
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Predložak je uređen');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * pošto je veza many to many malo to provjeriti
     */
    public function destroy(Klijent $klijent, Predlozak $predlozak)
    {
        try {
            $predlozak->destroy($predlozak->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Predložak je uspješno obrisan');
        return back();
    }
}
