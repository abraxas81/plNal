<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\ZbrojniNalog;
use Illuminate\Http\Request;
use Datatables;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;

class ZbrojniNalogController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci = [
            ['Naziv','Naziv','Naziv Naloga',0,true,true,true],
            ['created_at','ZbrojniNalog.created_at','Stvoreno',1,true,false,false],
            ['updated_at','ZbrojniNalog.updated_at','Ažurirano',2,true,false,false],
            ['count','count','Broj naloga',3,true,false,false],
            ['iznos','iznos','Iznos',4,true,false,false],
            ['action','Akcije','Akcije',5,true,false,false]
        ];

        view()->share('description', $this->getDescription('Zbrojni nalozi'));
        View::share('naslovTabele', 'Zbrojni Nalozi');
        View::share('naslovModala', 'Zbrojni nalog');
        View::share('textDodajGumba', 'Dodaj Zbrojni Nalog');
        View::share('tabelaStupci', $tabelaStupci);
        View::share('formName', 'zbrojniNalozi');
    }
    /**
     * Display a listing of the resource.
     *
     * @param Klijent $klijent
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Klijent $klijent, Request $request)
    {
        $vrstaNalogaF = $request->get('vrstaNaloga');
        return view('datatables.klijenti.zbrojniNalog.index', compact('klijent', 'vrstaNalogaF'));
    }

    public function BasicData(Klijent $klijent)
    {
        $zbrojniNalozi  = $klijent->zbrojniNalozi()->with('nalozi');

        $datatables =  app('datatables')->of($zbrojniNalozi)
            ->editColumn('created_at', function ($zbrojniNalozi) {
                return $zbrojniNalozi->created_at->format('d.m.Y H:i');
            })
            ->editColumn('created_at', function ($zbrojniNalozi) {
                return $zbrojniNalozi->updated_at->format('d.m.Y H:i');
            })
            ->editColumn('Naziv', function($zbrojniNalozi){
                return '<a href="zbrojniNalog/'.$zbrojniNalozi->id.'/nalozi">'.$zbrojniNalozi->Naziv.'</a>';
            })
            ->addColumn('count', function($zbrojniNalozi){
                return $zbrojniNalozi->nalozi()->count();
            })
            ->addColumn('iznos', function($zbrojniNalozi){
                return $zbrojniNalozi->nalozi()->sum('Iznos').' kn';
            })
            ->addColumn('action', function ($zbrojniNalozi) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="zbrojniNalog/'.$zbrojniNalozi->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="zbrojniNalog/'.$zbrojniNalozi->id.'" title="Obriši" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        <a href="#" class="datoteka" title="Datoteka zbrojnog naloga" data-action="zbrojniNalog/'.$zbrojniNalozi->id.'/datoteka"><i class="glyphicon glyphicon-share"></i></a>';
        });


        // vrsta Naloga filter
        if ($vrstaNalogaFilter = $datatables->request->get('vrstaNalogaFilter')) {
            $datatables->where('VrstaNalogaId',  $vrstaNalogaFilter);
        }

        // slovo search
        if ($alphabetSearch = $datatables->request->get('alphabetSearch')) {
            $datatables->where('Nalozi.Naziv', 'like', "$alphabetSearch%");
        }

        return $datatables->make(true);
    }

    public function datoteka(Klijent $klijent, ZbrojniNalog $zbrojniNalog){

        Storage::makeDirectory($zbrojniNalog->id); //result is 1


        $filename = "UN".date('Ymd').".txt";
        $file = new \SplFileObject($filename, "w+");

        Storage::disk('local')->put($zbrojniNalog->id.'/'.$filename, $file);

        $file->fwrite(date('Ymd') . $zbrojniNalog->VrstaNalogaId);

        $file->fwrite(str_pad(300, 991," ",STR_PAD_LEFT).PHP_EOL);

        $glaveSloga = ZbrojniNalog::glavaSloga($zbrojniNalog->id);

        $i = 1; //counter za linije datoteke
        
        foreach ($glaveSloga as $glavaSloga) {
            $file->seek($i);
            $file->fwrite(
                //-m-mandatory -o-obligatory
                str_pad($glavaSloga->IBAN,21).//IBAN platitelja (m)
                str_pad($glavaSloga->Alfa,3).//Oznaka valute plaćanja (m)
                str_pad("",21). //Račun naknade (o)
                str_pad("",3).  //Oznaka valute naknade (o)
                str_pad($glavaSloga->brojNaloga, 5, '0', STR_PAD_LEFT). //Ukupan broj naloga u sljedećoj grupi (slogovi 309) (m)
                str_pad(str_replace([",", ".", " kn"], [""], $glavaSloga->suma), 20, '0', STR_PAD_LEFT). //Ukupan iznos naloga u sljedećoj grupi (slogovi 309)(m)
                str_pad(str_replace(["-"], [""], $glavaSloga->DatumIzvrsenja),8). //Datum izvršenja naloga (m)
                str_pad("",916). //Rezerva
                str_pad(301,3). //Tip Sloga
                PHP_EOL); //kraj linije
            $i++; //counter za linije datoteke

            $nalozi = ZbrojniNalog::stavke($glavaSloga->VrstaNalogaId, $glavaSloga->id, $glavaSloga->IBAN, $glavaSloga->DatumIzvrsenja);

            foreach ($nalozi as $nalog) {
                $file->seek($i);
                $file->fwrite(
                    str_pad($nalog->ibanPrimatelja, 34). //IBAN ili račun primatelja (m)
                    str_pad($nalog->nazivPrimatelja, 70). //Naziv primatelja (ime i prezime) (m - 2,3,4)
                    str_pad("", 35). //Adresa primatelja (v-2)
                    str_pad("", 35). //Sjedište primatelja (v-2)
                    str_pad("", 3). //Šifra zemlje primatelja (v-2)
                    str_pad("HR" . $nalog->modelOdobrenja,4). //Broj modela platitelja (m*)
                    str_pad($nalog->BrojOdobrenja, 22). // Poziv na broj platitelja(m*)
                    str_pad("", 4). //Šifra namjene (o)
                    str_pad($nalog->Opis, 140). //Opis plaćanja (m)
                    str_pad(str_replace([",", ".", " kn"], [""], $nalog->Iznos), 15, '0', STR_PAD_LEFT). //Iznos (m)
                    str_pad("HR".$nalog->modelZaduzenja,4). //Broj modela primatelja (m*)
                    str_pad("",22). //Poziv na broj primatelja (m*)
                    str_pad("",11). //BIC (SWIFT) adresa (v)
                    str_pad("",70). //Naziv banke primatelja  (v)
                    str_pad("",35). //Adresa banke primatelja  (v)
                    str_pad("",35). //Sjedište banke primatelja  (v)
                    str_pad("",3). //Šifra zemlje banke primatelja (v)
                    str_pad("",1). //Vrsta strane osobe (v)
                    str_pad("",3). //Valuta pokrića  (v)
                    str_pad("",1). //Troškovna opcija (v)
                    str_pad("",1). //Oznaka hitnosti  (v)
                    str_pad("",3). //Šifra vrste osobnog primanja (m*)
                    str_pad("",446). //Rezerva (v)
                    str_pad(309,3). //Tip sloga
                    PHP_EOL);
                $i++;
            }
        }
        $file->fwrite(str_pad(399, 1000," ",STR_PAD_LEFT).PHP_EOL);
        $file = mb_convert_encoding($file, 'HTML-ENTITIES', "UTF-8");
        $file = null;

        Session::flash('message', 'Datoteka je uspješno generirana');

        return back();
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
