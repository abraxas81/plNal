<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\ModelPlacanja;
use App\Nalog;
use App\Predlozak;
use App\Valuta;
use App\SifraNamjene;
use App\ZbrojniNalog;
use Illuminate\Http\Request;
use Datatables;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Cache;

class ZnNaloziController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci = [
            ['platitelj.IBAN','platitelj.IBAN','Iban Platitelja',0,true,false,false],
            ['ModelOdobrenjaId','Nalozi.ModelOdobrenjaId','Model Odobrenja',1,true,false,false],
            ['BrojOdobrenja','Nalozi.BrojOdobrenja','Broj Odobrenja',2,true,true,true],
            ['primatelj.IBAN','primatelj.IBAN','Iban primatelja',3,true,false,false],
            ['ModelZaduzenjaId','Nalozi.ModelZaduzenjaId','Model Zaduženja',4,true,false,true],
            ['BrojZaduzenja','Nalozi.BrojZaduzenja','Broj Zaduženja',5,true,true,true],
            ['Iznos','Nalozi.Iznos','Iznos',6,true,true,true],
            ['Opis','Nalozi.Opis','Opis',7,true,true,true],
            ['DatumIzvrsenja','Nalozi.DatumIzvrsenja','Datum Izvršenja',8,true,true,true],
            ['valute.Alfa','valute.Alfa','Valuta',9,true,false,false],
            ['action','Akcije','Akcije',10,true,false,false]
        ];

        $tabelaStupci2 = [
            ['Naziv','Predlosci.Naziv','Naziv Predloška',0,true,true,true],
            ['platitelj.Naziv','Predlosci.Naziv','Naziv',1,true,false,false],
            ['ModelOdobrenjaId','Predlosci.ModelOdobrenjaId','Model Odobrenja',2,true,false,false],
            ['BrojOdobrenja','Predlosci.BrojOdobrenja','Broj Odobrenja',3,true,true,true],
            ['primatelj.IBAN','Predlosci.IBAN','Naziv',4,true,false,false],
            ['ModelZaduzenjaId','Predlosci.ModelZaduzenjaId','Model Zaduženja',5,true,false,true],
            ['BrojZaduzenja','Predlosci.BrojZaduzenja','Broj Zaduženja',6,true,true,true],
            ['Iznos','Predlosci.Iznos','Iznos',7,true,true,true],
            ['Opis','Predlosci.Opis','Opis',8,true,true,true],
            ['DatumIzvrsenja','Predlosci.DatumIzvrsenja','Datum Izvršenja',9,true,true,true],
            ['valute.Alfa','valute.Alfa','Valuta',10,true,false,false],
            ['action','Akcije','Akcije',11,true,false,false]
        ];

        view()->share('description', $this->getDescription('Predlosci'));
        if (!Cache::has("ModeliPlacanja")) {
            $ModeliPlacanja = ModelPlacanja::all();
            Cache::forever("ModeliPlacanja", $ModeliPlacanja);
        }
        if (!Cache::has("Valute")) {
            $Valute = Valuta::all();
            Cache::forever("Valute", $Valute);
        }
        if (!Cache::has("SifreNamjene")) {
            $SifreNamjene = SifraNamjene::all();
            Cache::forever("SifreNamjene", $SifreNamjene);
        }
        if (!Cache::has(Session::get('klijentId')."Platitelji")) {
            Cache::forever(Session::get('klijentId') . "Platitelji", Klijent::find(Session::get('klijentId'))->partneri()->with('ziroRacuni')->Platitelj());
        }
        View::share(['Partneri' => Cache::get(Session::get('klijentId').'Platitelji')->get()]);
        View::share(['Primatelji' => Cache::get('Primatelji')]);
        View::share(['SifreNamjene' =>  Cache::get("SifreNamjene")] );
        View::share(['Valute' =>  Cache::get("Valute")] );
        View::share(['ModeliPlacanja' =>  Cache::get("ModeliPlacanja")] );

        View::share('naslovTabele', 'Nalozi');
        View::share('naslovModala', 'Nalog za plaćanje');
        View::share('textDodajGumba', 'Dodaj Nalog');
        View::share('tabelaStupci', $tabelaStupci);
        View::share('tabelaStupci2', $tabelaStupci2);
        View::share('predlozak', false);
        View::share('selectedPredlosci', false);
        View::share('formName', 'predlozak');
        View::share('formPartneriName', 'partneri');
        View::share('rutaDohvatPartnera', '../../ziro/');
        View::share('RutaProvjeraIbana', '../../ProvjeraIbana/');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Request $request)
    {
        $vrstaNalogaF = $request->get('vrstaNaloga');
        return view('datatables.klijenti.zbrojniNalog.nalozi.index', compact('klijent','zbrojniNalog','vrstaNalogaF'));
    }

    public function BasicData(Klijent $klijent, ZbrojniNalog $zbrojniNalog)
    {
        $nalozi = $zbrojniNalog->nalozi()->with('platitelj','primatelj','valute')->get();

        $datatables =  app('datatables')->of($nalozi)
            ->editColumn('DatumIzvrsenja', function ($nalozi) {
                return date('d.m.Y',strtotime($nalozi->DatumIzvrsenja));
            })
            ->editColumn('platitelj.Naziv', function ($nalozi) {
                return '<a href="#" class="detalji" data-action="'.$nalozi->platitelj->id.'" data-title="Podaci o platitelju">'.$nalozi->platitelj->Naziv.'</a>';
            })
            ->editColumn('primatelj.Naziv', function ($nalozi) {
                return '<a href="#" class="detalji" data-action="'.$nalozi->primatelj->id.'" data-title="Podaci o primatelju">'.$nalozi->primatelj->Naziv.'</a>';
            })
            ->editColumn('Naziv', function ($nalozi) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-target="#Modal" data-action="../../nalozi/'.$nalozi->id.'">'.$nalozi->Naziv.'</a>';
            })
            ->addColumn('action', function ($nalozi) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-platitelj="'.$nalozi->PlatiteljId.'" data-primatelj="'.$nalozi->ZiroPrimatelja.'" data-target="#Modal" data-action="../../nalozi/'.$nalozi->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="nalozi/'.$nalozi->id.'" title="Obriši" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        ';
            });

        // vrsta Naloga filter
        if ($vrstaNalogaFilter = $datatables->request->get('vrstaNalogaFilter')) {
            $datatables->where('VrstaNalogaId',  $vrstaNalogaFilter);
        }

        // slovo search
        if ($alphabetSearch = $datatables->request->get('alphabetSearch')) {
            $datatables->where('Nalozi.Naziv', 'like', "$alphabetSearch%");
        }

        return $datatables->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Request $request)
    {
        try {
            $request->merge(['DatumIzvrsenja' => date('Y-m-d', strtotime($request->input('DatumIzvrsenja')))]);
            $nalog = Nalog::create($request->all());
            $nalog->klijenti()->sync($klijent->id);
            $nalog->zbrojniNalozi()->sync($zbrojniNalog->id);
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je kreiran');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function show(Klijent $klijent, ZbrojniNalog $zbrojniNalog,Nalog $nalog)
    {
        return response()->json($nalog->load(['primatelj','primatelj.partneri']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function update(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Nalog $nalog, Request $request)
    {
        try {
            $request->merge(['DatumIzvrsenja' => date('Y-m-d', strtotime($request->input('DatumIzvrsenja')))]);
            $nalog = Nalog::create($request->all());
            $nalog->klijenti()->sync($klijent->id);
            $nalog->zbrojniNalozi()->sync($zbrojniNalog->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je uređen');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function destroy(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Nalog $nalog)
    {
        try {
            $nalog->destroy($nalog->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je uspješno obrisan');
        return back();
    }
}
