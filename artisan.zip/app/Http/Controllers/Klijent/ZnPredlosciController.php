<?php

namespace App\Http\Controllers\Klijent;

use App\Klijent;
use App\ModelPlacanja;
use App\Nalog;
use App\Predlozak;
use App\Valuta;
use App\SifraNamjene;
use App\ZbrojniNalog;
use Illuminate\Http\Request;
use Datatables;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Laracasts\Flash\Flash;
use App\Services\PorukeOperaterima;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Cache;

class ZnPredlosciController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
        //['key'] => ['displayTitle',position, 'visible','searchable', 'orderable']
        $tabelaStupci2 = [
            ['Naziv','Naziv','Naziv Predloška',0,true,true,true],
            ['platitelj.IBAN','Predlosci.Naziv','Iban Platitelja',1,true,false,false],
            ['ModelOdobrenjaId','Predlosci.ModelOdobrenjaId','Model Odobrenja',2,true,false,false],
            ['BrojOdobrenja','Predlosci.BrojOdobrenja','Broj Odobrenja',3,true,true,true],
            ['primatelj.IBAN','Predlosci.IBAN','Iban Primatelja',4,true,false,false],
            ['ModelZaduzenjaId','Predlosci.ModelZaduzenjaId','Model Zaduženja',5,true,false,true],
            ['BrojZaduzenja','Predlosci.BrojZaduzenja','Broj Zaduženja',6,true,true,true],
            ['Iznos','Predlosci.Iznos','Iznos',7,true,true,true],
            ['Opis','Predlosci.Opis','Opis',8,true,true,true],
            ['valute.Alfa','valute.Alfa','Valuta',9,true,false,false],
            ['action','Akcije','Akcije',10,true,false,false]
        ];
        
        view()->share('description', $this->getDescription('Predlosci'));
        if (!Cache::has("ModeliPlacanja")) {
            $ModeliPlacanja = ModelPlacanja::all();
            Cache::forever("ModeliPlacanja", $ModeliPlacanja);
        }
        if (!Cache::has("Valute")) {
            $Valute = Valuta::all();
            Cache::forever("Valute", $Valute);
        }
        if (!Cache::has("SifreNamjene")) {
            $SifreNamjene = SifraNamjene::all();
            Cache::forever("SifreNamjene", $SifreNamjene);
        }
        if (!Cache::has(Session::get('klijentId')."Platitelji")) {
            Cache::forever(Session::get('klijentId') . "Platitelji", Klijent::find(Session::get('klijentId'))->partneri()->with('ziroRacuni')->Platitelj());
        }
        View::share(['Partneri' => Cache::get(Session::get('klijentId').'Platitelji')->get()]);
        View::share(['Primatelji' => Cache::get('Primatelji')]);
        View::share(['SifreNamjene' =>  Cache::get("SifreNamjene")] );
        View::share(['Valute' =>  Cache::get("Valute")] );
        View::share(['ModeliPlacanja' =>  Cache::get("ModeliPlacanja")] );

        View::share('naslovTabele', 'Predlošci');
        View::share('naslovModala', 'Predložak naloga za nacionalno plaćanje u kunama');
        View::share('textDodajGumba', 'Dodaj Predložak');
        View::share('tabelaStupci2', $tabelaStupci2);
        View::share('predlozak', true);
        View::share('selectedPredlosci', true);
        View::share('formName', 'predlozak');
        View::share('formPartneriName', 'partneri');
        View::share('rutaDohvatPartnera', '../../ziro/');
        View::share('RutaProvjeraIbana', '../../ProvjeraIbana');

    }    

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Request $request)
    {
        $vrstaNalogaF = $request->get('vrstaNaloga');
        return view('datatables.klijenti.zbrojniNalog.nalozi.index', compact('klijent','zbrojniNalog','vrstaNalogaF'));
    }

    public function BasicData(Klijent $klijent, ZbrojniNalog $zbrojniNalog)
    {
        $predlosci = $klijent->predlosci()->with('platitelj','primatelj','valute');

        $datatables =  app('datatables')->of($predlosci)
            ->editColumn('DatumIzvrsenja', function ($predlosci) {
                return date('d.m.Y',strtotime($predlosci->DatumIzvrsenja));
            })
            ->editColumn('platitelj.Naziv', function ($predlosci) {
                return '<a href="#" class="detalji" data-action="../../predlosci/'.$predlosci->PlatiteljId.'" data-title="Podaci o platitelju">'.$predlosci->platitelj->IBAN.'</a>';
            })
            ->editColumn('primatelj.Naziv', function ($predlosci) {
                return '<a href="#" class="detalji" data-action="../../predlosci/'.$predlosci->ZiroPrimatelja.'" data-title="Podaci o primatelju">'.$predlosci->primatelj->IBAN.'</a>';
            })
            ->addColumn('action', function ($predlosci) {
                return '<a href="#" class="edit" title="Uredi" data-toggle="modal" data-platitelj="'.$predlosci->PlatiteljId.'" data-primatelj="'.$predlosci->ZiroPrimatelja.'" data-target="#Modal" data-action="../../predlosci/'.$predlosci->id.'"><span class="glyphicon glyphicon-edit" ></i></a>
                        <a href="../../predlosci/'.$predlosci->id.'" title="Obriši" data-method="delete" data-confirm="Jeste li sigurni?"><i class="glyphicon glyphicon-trash"></i></a>
                        <a href="#" class="edit odaberiPredlozak" title="Odaberi Predložak" data-toggle="modal" data-target="#Modal" data-platitelj="'.$predlosci->PlatiteljId.'" data-primatelj="'.$predlosci->ZiroPrimatelja.'" data-action="../../predlosci/'.$predlosci->PlatiteljId.'"><i class="glyphicon glyphicon-share-alt"></i></a>
                        ';
            });

        // vrsta Naloga filter
        if ($vrstaNalogaFilter = $datatables->request->get('vrstaNalogaFilter')) {
            $datatables->where('VrstaNalogaId',  $vrstaNalogaFilter);
        }

        // slovo search
        if ($alphabetSearch = $datatables->request->get('alphabetSearch')) {
            $datatables->where('Nalozi.Naziv', 'like', "$alphabetSearch%");
        }

        return $datatables->make(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Request $request)
    {
        try {
            $request->merge(['DatumIzvrsenja' => date('Y-m-d', strtotime($request->input('DatumIzvrsenja')))]);
            $nalog = Nalog::create($request->all());
            $nalog->klijenti()->sync($klijent->id);
            $nalog->zbrojniNalozi()->sync($zbrojniNalog->id);
        }catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je kreiran');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  Klijent $klijent
     * @param  Predlozak $predlozak
     * @return \Illuminate\Http\Response
     */
    public function show(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Predlozak $predlozak)
    {
        return response()->json($predlozak->load(['primatelj','primatelj.partneri']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function update(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Nalog $nalog, Request $request)
    {
        try {
            $request->merge(['DatumIzvrsenja' => date('Y-m-d', strtotime($request->input('DatumIzvrsenja')))]);
            $nalog = Nalog::create($request->all());
            $nalog->klijenti()->sync($klijent->id);
            $nalog->zbrojniNalozi()->sync($zbrojniNalog->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je uređen');
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Klijent $klijent
     * @param  Nalog $nalog
     * @return \Illuminate\Http\Response
     */
    public function destroy(Klijent $klijent, ZbrojniNalog $zbrojniNalog, Nalog $nalog)
    {
        try {
            $nalog->destroy($nalog->id);
        } catch (\Illuminate\Database\QueryException $e) {
            dd($e->errorInfo[1]);
            Flash::error(PorukeOperaterima::sqlPoruka($e->errorInfo[1]));
            return back();
        }
        Flash::success('Nalog je uspješno obrisan');
        return back();
    }
}
