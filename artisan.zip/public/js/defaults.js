/**
 * Created by Saša on 6.3.2016..
 */
var datableLanguage =
    {
        "sEmptyTable":      "Nema podataka u tablici",
        "sInfo":            "Prikazano _START_ do _END_ od _TOTAL_ rezultata",
        "sInfoEmpty":       "Prikazano 0 do 0 od 0 rezultata",
        "sInfoFiltered":    "(filtrirano iz _MAX_ ukupnih rezultata)",
        "sInfoPostFix":     "",
        "sInfoThousands":   ",",
        "sLengthMenu":      "Prikaži _MENU_ rezultata po stranici",
        "sLoadingRecords":  "Dohvaćam...",
        "sProcessing":      "Obrađujem...",
        "sSearch":          "Pretraži:",
        "sZeroRecords":     "Ništa nije pronađeno",
        "oPaginate": {
            "sFirst":       "Prva",
            "sPrevious":    "Nazad",
            "sNext":        "Naprijed",
            "sLast":        "Zadnja"
        },
        "oAria": {
            "sSortAscending":  ": aktiviraj za rastući poredak",
            "sSortDescending": ": aktiviraj za padajući poredak"
        }
    }

$.extend($.fn.DataTable.defaults,{autoWidth:false,responsive:true,deferRender:true,stateSave:false,processing:true,serverSide: true,sPaginationType:'full_numbers',lengthMenu:[[10,25,50,100,200,-1],[10,25,50,100,200,"All"]],iDisplayLength:100,dom:"R<'row'<'col-xs-4'l><'col-xs-4'<'table_title'>><'col-xs-4'f>r>"+"t"+"<'row'<'col-xs-6'i><'col-xs-6'p>>"});
$.fn.select2.defaults.set("language", "hr");
$.fn.select2.defaults.set('allowClear', false);
$.fn.select2.defaults.set('width', 'resolve');

