@extends('datatables.template2')

@section('breadcrumbs')
    {!! Breadcrumbs::render('admin.operateri.index') !!}
    @section('filters')
        <form id="filteri">
            <div class="splynx-nav-right">
                <input id="refresh" type="button" class="btn btn-primary btn-sm" value="Osvježi ">
                <a class="btn btn-sm btn-primary novi" data-toggle="modal" data-target="#Modal" data-action="admin/operateri"><i class="glyphicon glyphicon-edit"></i> {{$textDodajGumba}}</a>
            </div>
        </form>
    @endsection
@endsection

@section('demo')
    <table id="table" class="display supertable table table-striped table-bordered dataTable no-footer dtr-inline">
        <thead>
        <tr>
            @foreach($tabelaStupci as $tabelaStupac)
                <th>{{$tabelaStupac[2]}}</th>
                <script type="text/javascript"> columns.push({!! json_encode($tabelaStupac) !!})</script>
            @endforeach
        </tr>
        </thead>
    </table>
@endsection

@section('form')
    @include('datatables.admin.operateri.form')
    @include('datatables.admin.partials.selectZaUloge')
@endsection

@section('js')
    <script type="text/javascript">

        var tableId = "table";

        var url = '{{ url("admin/operateri/basic-data") }}';

        var filteri = {
        }

        var table = $('#'+tableId).DataTable({
            language : datableLanguage,
            ajax:{
                url : url,
                data: function (d) {
                    $.each(filteri, function(key,value){
                        d[key] = value;
                    })
                }
            },
            "columnDefs" : vidljivost(columns)
        });

        $('#refresh').on('click', function(){
            table.draw();
        })

        $('.table_title').html('{{$naslovTabele}}');

    </script>
@endsection