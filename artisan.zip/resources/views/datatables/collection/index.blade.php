@extends('app')

@section('content')
    <h2 class="page-header">{!! $title !!}</h2>
@stop